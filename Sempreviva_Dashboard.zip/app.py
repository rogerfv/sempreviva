import streamlit as st
import re
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import unicodedata
import sqlite3
import hashlib
from pathlib import Path
from io import BytesIO
from datetime import datetime
import google.generativeai as genai
import matplotlib.pyplot as plt

# ===== DATABASE SETUP =====
DB_PATH = "financial_data.db"

def init_database():
    """Initialize SQLite database with tables for files and data"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Table for tracking uploaded files
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS uploaded_files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            file_hash TEXT UNIQUE NOT NULL,
            filename TEXT NOT NULL,
            file_type TEXT NOT NULL,
            month TEXT NOT NULL,
            upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            data BLOB NOT NULL
        )
    """)
    
    conn.commit()
    conn.close()

def get_file_hash(file_content):
    """Generate hash for file content to detect duplicates"""
    return hashlib.md5(file_content).hexdigest()

def save_file_to_db(filename, file_type, month, file_content):
    """Save file to database"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    file_hash = get_file_hash(file_content)
    
    try:
        cursor.execute("""
            INSERT INTO uploaded_files (file_hash, filename, file_type, month, data)
            VALUES (?, ?, ?, ?, ?)
        """, (file_hash, filename, file_type, month, file_content))
        conn.commit()
        return True, "File saved successfully"
    except sqlite3.IntegrityError:
        return False, "File already exists in database"
    finally:
        conn.close()

def get_all_files():
    """Retrieve all files from database"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT id, filename, file_type, month, upload_date, data
        FROM uploaded_files
        ORDER BY month, file_type
    """)
    
    files = cursor.fetchall()
    conn.close()
    
    return files

def delete_file_from_db(file_id):
    """Delete file from database"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("DELETE FROM uploaded_files WHERE id = ?", (file_id,))
    conn.commit()
    conn.close()

def get_files_by_type(file_type):
    """Get all files of a specific type"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT id, filename, month, data
        FROM uploaded_files
        WHERE file_type = ?
        ORDER BY month
    """, (file_type,))
    
    files = cursor.fetchall()
    conn.close()
    
    return files

# ===== CONFIG =====
ONLY_PAID = False

# INCOME CONFIGURATION
PRODUCT_CATEGORY_RULES = [
    ("nuvies", "Novias"),
    ("complements", "Complementos"),
    ("premsades", "Premsades"),
    ("decoracions", "Decoracions"),
    ("b2b", "B2B"),
    ("florece", "Formaciones"),
    ("formacion", "Formaciones"),
]
PRODUCT_DEFAULT = "Productos web, cuadros, cúpulas y varios"

CHANNEL_RULES = [
    ("instagram", "Instagram"),
    ("#ig", "Instagram"),
    ("tiktok", "TikTok"),
    ("google", "Google"),
    ("madrigal", "Madrigal"),
    ("referencies", "Referencias"),
    ("proveidors", "Proveedores"),
]
CHANNEL_DEFAULT = "Sin identificar"
#CHANNEL_PRODUCT_ONLY = "No aplica (solo producto)"

PHRASE_RAMO = "pago a cuenta ramo de novia"
PHRASE_PRENSADO = "pago a cuenta cuadro prensado"

# EXPENSE CONFIGURATION
EXPENSE_RULES = [
    ("alquiler", "Alquiler del local"),
    ("salario", "Salarios y sueldos del personal fijo"),
    ("nómina", "Salarios y sueldos del personal fijo"),
    ("nomina", "Salarios y sueldos del personal fijo"),
    ("electricidad", "Servicios: Electricidad, agua, gas"),
    ("luz", "Servicios: Electricidad, agua, gas"),
    ("agua", "Servicios: Electricidad, agua, gas"),
    ("gas", "Servicios: Electricidad, agua, gas"),
    ("seguro", "Seguro del local"),
    ("licencia", "Costos de licencias y permisos"),
    ("permiso", "Costos de licencias y permisos"),
    ("limpieza", "Materiales de limpieza"),
    ("marketing", "Publicidad y marketing"),
    ("publicidad", "Publicidad y marketing"),
    ("ads", "Publicidad y marketing"),
    ("oficina", "Productos de oficina"),
    ("papeler", "Productos de oficina"),
    ("mantenimiento", "Mantenimiento y reparaciones y muebles"),
    ("reparaci", "Mantenimiento y reparaciones y muebles"),
    ("mueble", "Mantenimiento y reparaciones y muebles"),
    ("gestor", "Servicios de gestoría"),
    ("autónomo", "Cuota de autónomos"),
    ("autonomo", "Cuota de autónomos"),
    ("formaci", "Formación"),
    ("banca", "Gastos bancarios"),
    ("comisi", "Gastos bancarios"),
    ("web", "Web, comunicación, sistemas"),
    ("hosting", "Web, comunicación, sistemas"),
    ("dominio", "Web, comunicación, sistemas"),
    ("software", "Web, comunicación, sistemas"),
    ("sistem", "Web, comunicación, sistemas"),
    ("it", "Web, comunicación, sistemas"),
    ("automat", "Web, comunicación, sistemas"),
    ("telef", "Telefonía"),
    ("asesor", "Asesorías"),
    ("asessor", "Asesorías"),
    ("flor", "Flores"),
    ("cristal", "Materiales (cristales etc)"),
    ("material", "Materiales (cristales etc)"),
    ("packaging", "Packaging"),
    ("embalaje", "Packaging"),
    ("mensaj", "Mensajería"),
    ("envío", "Mensajería"),
    ("envio", "Mensajería"),
    ("courier", "Mensajería"),
    ("inmoviliz", "Inmovilizados: maderas prensa"),
    ("madera", "Inmovilizados: maderas prensa"),
    ("contrataci", "Contrataciones temporales - impuestos"),
    ("temporal", "Contrataciones temporales - impuestos"),
    ("irpf", "Impuestos sobre la renta IRPF"),
    ("pago trimestral", "Pagos trimestrales impuestos"),
    ("trimestral", "Pagos trimestrales impuestos"),
]
EXPENSE_DEFAULT = "Otros"

FIXED_TYPES = [
    "Alquiler del local",
    "Salarios y sueldos del personal fijo",
    "Servicios: Electricidad, agua, gas",
    "Seguro del local",
    "Costos de licencias y permisos",
    "Materiales de limpieza",
    "Publicidad y marketing",
    "Productos de oficina",
    "Mantenimiento y reparaciones y muebles",
    "Servicios de gestoría",
    "Cuota de autónomos",
    "Formación",
    "Gastos bancarios",
    "Web, comunicación, sistemas",
    "Telefonía",
    "Asesorías",
    "Otros",
]

VARIABLE_TYPES = [
    "Flores",
    "Materiales (cristales etc)",
    "Packaging",
    "Mensajería",
    "Inmovilizados: maderas prensa",
    "Contrataciones temporales - impuestos",
    "Impuestos sobre la renta IRPF",
    "Pagos trimestrales impuestos",
    "Otros",
]

AMOUNT_CANDIDATES = ["Total", "Importe", "Amount", "Ingreso", "Income", "Gasto", "Coste", "Base imponible"]

# ===== HELPERS =====
def _strip_accents(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))

def normalize_text(x: object) -> str:
    t = "" if pd.isna(x) else str(x)
    t = _strip_accents(t).lower().strip()
    return t

def find_header_row(df_raw):
    for i in range(min(40, len(df_raw))):
        row_vals = df_raw.iloc[i].astype(str).str.strip().str.lower().tolist()
        if any(kw in row_vals for kw in ["tags", "cuenta", "fecha emisión", "fecha emision"]):
            return i
    return 0

def load_table(file_content):
    df_raw = pd.read_excel(BytesIO(file_content), header=None, dtype=str)
    header_row = find_header_row(df_raw)
    df = pd.read_excel(BytesIO(file_content), header=header_row)
    df.columns = [str(c).strip() for c in df.columns]
    return df.dropna(how="all")

def pick_amount_column(df):
    for cand in AMOUNT_CANDIDATES:
        if cand in df.columns:
            return cand
    for c in df.columns:
        coerced = pd.to_numeric(df[c], errors="coerce")
        if coerced.notna().any():
            df[c] = coerced
            return c
    raise ValueError("No numeric amount column found.")

def month_label_from_filename(filename):
    m = re.search(r"(Ingresos|Compras) (\d{2})_(\d{2})_(\d{4})-(\d{2})_(\d{2})_(\d{4})", filename)
    if m:
        dd, mm, yyyy = m.group(2), m.group(3), m.group(4)
        return f"{yyyy}-{mm}"
    return filename[:31]

def unique_labels_in_order_from_rules(rules, extras=()):
    seen, out = set(), []
    for _, lab in rules:
        if lab not in seen:
            out.append(lab)
            seen.add(lab)
    for lab in extras:
        if lab not in seen:
            out.append(lab)
            seen.add(lab)
    return out

# ===== INCOME ANALYSIS =====
def _first_match_from_rules(text, rules):
    t = text.lower()
    for sub, label in rules:
        if sub.lower() in t:
            return label
    return None

def _has_any_keyword(text, rules):
    t = text.lower()
    return any(sub.lower() in t for sub, _ in rules)

def map_product(tags_val):
    if pd.isna(tags_val):
        return PRODUCT_DEFAULT
    label = _first_match_from_rules(str(tags_val), PRODUCT_CATEGORY_RULES)
    return label if label is not None else PRODUCT_DEFAULT

def map_channel(tags_val):
    if pd.isna(tags_val):
        return CHANNEL_DEFAULT
    text = str(tags_val)
    ch_label = _first_match_from_rules(text, CHANNEL_RULES)
    if ch_label is not None:
        return ch_label
    #if _has_any_keyword(text, PRODUCT_CATEGORY_RULES):
        #return CHANNEL_PRODUCT_ONLY
    return CHANNEL_DEFAULT

def map_pago_tipo(desc):
    s = str(desc).casefold()
    if PHRASE_RAMO in s:
        return "Pago a cuenta ramo de novia"
    if PHRASE_PRENSADO in s:
        return "Pago a cuenta cuadro prensado"
    return None

def build_pagos_counts(df_clean, all_channels):
    if "Descripción" not in df_clean.columns:
        counts = pd.DataFrame(
            index=all_channels,
            columns=["Pago a cuenta ramo de novia", "Pago a cuenta cuadro prensado"]
        ).fillna(0).astype(int)
        counts["Total"] = counts.sum(axis=1)
        totals_row = counts.sum(axis=0).to_frame().T
        totals_row.index = ["Total"]
        return pd.concat([counts, totals_row], axis=0)
    
    tmp = df_clean.copy()
    tmp["Tipo"] = tmp["Descripción"].apply(map_pago_tipo)
    tmp = tmp[tmp["Tipo"].notna()].copy()
    
    if tmp.empty:
        counts = pd.DataFrame(
            index=all_channels,
            columns=["Pago a cuenta ramo de novia", "Pago a cuenta cuadro prensado"]
        ).fillna(0).astype(int)
    else:
        counts = (
            tmp.groupby(["Canal", "Tipo"]).size()
            .unstack(fill_value=0)
            .reindex(
                index=all_channels,
                columns=["Pago a cuenta ramo de novia", "Pago a cuenta cuadro prensado"],
                fill_value=0
            )
        )
    
    counts["Total"] = counts.sum(axis=1)
    totals_row = counts.sum(axis=0).to_frame().T
    totals_row.index = ["Total"]
    return pd.concat([counts, totals_row], axis=0)

def analyze_income_df(df, amount_col):
    if ONLY_PAID and "Estado" in df.columns:
        df = df[df["Estado"].astype(str).str.lower().str.strip() == "pagado"].copy()

    if "Tags" not in df.columns:
        raise ValueError("The Excel does not contain a 'Tags' column.")

    df[amount_col] = pd.to_numeric(df[amount_col], errors="coerce")
    df["Categoría"] = df["Tags"].apply(map_product)
    df["Canal"] = df["Tags"].apply(map_channel)

    ALL_CATEGORIES = unique_labels_in_order_from_rules(PRODUCT_CATEGORY_RULES, (PRODUCT_DEFAULT,))
    #ALL_CHANNELS = unique_labels_in_order_from_rules(CHANNEL_RULES, (CHANNEL_PRODUCT_ONLY, CHANNEL_DEFAULT))
    ALL_CHANNELS = unique_labels_in_order_from_rules(CHANNEL_RULES, (CHANNEL_DEFAULT,))
    
    grand_total = float(pd.to_numeric(df[amount_col], errors="coerce").sum())
    if grand_total == 0:
        grand_total = np.nan

    tot_cat = (
        df.groupby("Categoría", dropna=False)[amount_col]
        .sum(min_count=1).fillna(0)
        .reindex(ALL_CATEGORIES)
        .reset_index()
        .rename(columns={amount_col: "Total"})
    )
    tot_cat["Porcentaje"] = (tot_cat["Total"] / grand_total * 100).round(2)

    tot_channel = (
        df.groupby("Canal", dropna=False)[amount_col]
        .sum(min_count=1).fillna(0)
        .reindex(ALL_CHANNELS)
        .reset_index()
        .rename(columns={amount_col: "Total"})
    )
    tot_channel["Porcentaje"] = (tot_channel["Total"] / grand_total * 100).round(2)

    pivot = (
        df.groupby(["Canal", "Categoría"], dropna=False)[amount_col]
        .sum(min_count=1).fillna(0)
        .unstack(fill_value=0)
    ).reindex(index=ALL_CHANNELS, columns=ALL_CATEGORIES, fill_value=0)

    pivot_with_totals = pivot.copy()
    pivot_with_totals["Total canal (€)"] = pivot_with_totals.sum(axis=1)
    row_total = pd.DataFrame([pivot_with_totals.sum(axis=0)], index=["Total (€)"])
    pivot_with_totals = pd.concat([pivot_with_totals, row_total], axis=0)

    pivot_pct = (pivot / grand_total * 100)
    channel_totals_pct = (pivot.sum(axis=1) / grand_total * 100)
    category_totals_pct = (pivot.sum(axis=0) / grand_total * 100)
    
    pivot_pct_with_totals = pivot_pct.copy()
    pivot_pct_with_totals["Total canal (%)"] = channel_totals_pct
    row_total_pct = pd.DataFrame([category_totals_pct], index=["Total (%)"])
    row_total_pct["Total canal (%)"] = 100.0
    pivot_pct_with_totals = pd.concat([pivot_pct_with_totals, row_total_pct], axis=0)
    pivot_pct_with_totals = pivot_pct_with_totals.round(2)

    pagos_counts = build_pagos_counts(df, ALL_CHANNELS)

    return {
        "tot_cat": tot_cat.sort_values("Total", ascending=False),
        "tot_channel": tot_channel.sort_values("Total", ascending=False),
        "pivot_eur": pivot_with_totals,
        "pivot_pct": pivot_pct_with_totals,
        "df_clean": df,
        "all_channels": ALL_CHANNELS,
        "pagos_counts": pagos_counts,
        "grand_total": grand_total,
    }

# ===== EXPENSE ANALYSIS =====
def map_expense(cuenta_val):
    if pd.isna(cuenta_val):
        return EXPENSE_DEFAULT
    txt = normalize_text(cuenta_val)
    for sub, label in EXPENSE_RULES:
        if normalize_text(sub) in txt:
            return label
    return EXPENSE_DEFAULT

def analyze_expense_df(df, amount_col):
    if ONLY_PAID and "Estado" in df.columns:
        df = df[df["Estado"].astype(str).str.lower().str.strip() == "pagado"].copy()

    if "Cuenta" not in df.columns:
        raise ValueError("El Excel no contiene la columna 'Cuenta'.")

    df[amount_col] = pd.to_numeric(df[amount_col], errors="coerce")
    df["Tipo gasto"] = df["Cuenta"].apply(map_expense)

    ALL_TYPES = unique_labels_in_order_from_rules(EXPENSE_RULES, (EXPENSE_DEFAULT,))

    grand_total = float(pd.to_numeric(df[amount_col], errors="coerce").sum())
    if grand_total == 0:
        grand_total = np.nan

    tot_types = (
        df.groupby("Tipo gasto", dropna=False)[amount_col]
        .sum(min_count=1)
        .reindex(ALL_TYPES)
        .fillna(0)
        .reset_index()
        .rename(columns={amount_col: "Total"})
    )
    tot_types["Porcentaje"] = (tot_types["Total"] / grand_total * 100).round(2).fillna(0)

    tot_vars = (
        tot_types.set_index("Tipo gasto")
        .reindex(VARIABLE_TYPES)
        .fillna(0)
        .reset_index()
        .rename(columns={"Tipo gasto": "Tipo gasto"})
    )
    tot_vars["Porcentaje"] = (tot_vars["Total"] / grand_total * 100).round(2).fillna(0)

    tot_fixed = (
        tot_types.set_index("Tipo gasto")
        .reindex(FIXED_TYPES)
        .fillna(0)
        .reset_index()
        .rename(columns={"Tipo gasto": "Tipo gasto"})
    )
    tot_fixed["Porcentaje"] = (tot_fixed["Total"] / grand_total * 100).round(2).fillna(0)

    unknown_accounts = (
        df.loc[df["Tipo gasto"] == EXPENSE_DEFAULT, ["Cuenta", amount_col]]
        .assign(Count=1)
        .groupby("Cuenta", dropna=False)
        .agg(Total=(amount_col, "sum"), Aparece=("Count", "sum"))
        .reset_index()
        .sort_values("Total", ascending=False)
    )

    return {
        "tot_types": tot_types.sort_values("Total", ascending=False),
        "tot_vars": tot_vars,
        "tot_fixed": tot_fixed,
        "unknown_accounts": unknown_accounts,
        "df_clean": df,
        "grand_total": grand_total,
    }

# ===== AI ANALYSIS FUNCTION =====
def generate_ai_insights(income_monthly_results, expense_monthly_results, total_income, total_expense, profit, api_key):
    """Generate AI insights using Google Gemini API"""
    try:
        # Configure Gemini
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel('gemini-2.5-flash')  # Updated model name
        
        # Prepare data summary for AI
        months_order = sorted(set(
            [m for m, _ in income_monthly_results] + 
            [m for m, _ in expense_monthly_results]
        ))
        
        # Monthly income and expense trends
        monthly_data = []
        for month in months_order:
            income_val = 0
            expense_val = 0
            
            for m, res in income_monthly_results:
                if m == month:
                    income_val = res["grand_total"]
                    break
            
            for m, res in expense_monthly_results:
                if m == month:
                    expense_val = res["grand_total"]
                    break
            
            monthly_data.append({
                "month": month,
                "income": income_val,
                "expense": expense_val,
                "profit": income_val - expense_val
            })
        
        # Income breakdown by category
        income_categories = ""
        if income_monthly_results:
            _, latest_income = income_monthly_results[-1]
            income_categories = latest_income["tot_cat"].to_string()
        
        # Expense breakdown by type
        expense_types = ""
        if expense_monthly_results:
            _, latest_expense = expense_monthly_results[-1]
            expense_types = latest_expense["tot_types"].to_string()
        
        # Create prompt for AI
        prompt = f"""
You are a financial analyst for a small business. Analyze the following financial data and provide:
1. A brief summary of the overall financial health (2-3 sentences)
2. Key insights and trends (3-4 bullet points)
3. Areas of concern or potential issues (2-3 bullet points)
4. Recommendations for improvement (2-3 bullet points)

Be specific with numbers and percentages. Focus on actionable insights.

FINANCIAL DATA:
- Total Income: €{total_income:,.2f}
- Total Expenses: €{total_expense:,.2f}
- Net Profit: €{profit:,.2f}
- Profit Margin: {(profit/total_income*100) if total_income > 0 else 0:.1f}%
- Number of months analyzed: {len(months_order)}

MONTHLY TREND DATA:
{pd.DataFrame(monthly_data).to_string()}

LATEST INCOME BREAKDOWN BY CATEGORY:
{income_categories}

LATEST EXPENSE BREAKDOWN BY TYPE:
{expense_types}

Please provide a concise, practical analysis focusing on the most important insights.
"""
        
        # Generate response
        response = model.generate_content(prompt)
        return response.text
        
    except Exception as e:
        return f"Error generating AI insights: {str(e)}"

# ===== STREAMLIT APP =====
st.set_page_config(page_title="Financial Dashboard", layout="wide")

# Initialize database
init_database()

st.title("📊 Complete Financial Dashboard")

# AI Settings in Sidebar
st.sidebar.header("🤖 AI Analysis Settings")
enable_ai = st.sidebar.checkbox("Enable AI Insights", value=False, help="Get AI-powered analysis of your financial data")

gemini_api_key = None
if enable_ai:
    gemini_api_key = st.sidebar.text_input(
        "Google Gemini API Key",
        type="password",
        help="Get your free API key at https://makersuite.google.com/app/apikey"
    )
    if not gemini_api_key:
        st.sidebar.warning("⚠️ Please enter your Gemini API key to enable AI insights")
    else:
        st.sidebar.success("✅ AI insights enabled")

st.sidebar.divider()

# Create tabs for main interface
main_tab1, main_tab2, main_tab3 = st.tabs(["📂 Upload & Manage Files", "📈 Financial Analysis", "⚖️ Period Comparison"])

# TAB: File Management
with main_tab1:
    st.header("File Management")
    
    st.subheader("📤 Upload New Files")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Income Files (Ingresos)**")
        income_files = st.file_uploader(
            "Upload Income Files",
            type=["xlsx"],
            accept_multiple_files=True,
            help="Upload monthly income Excel files",
            key="income_upload",
            label_visibility="collapsed"
        )
        
        if income_files:
            for file in income_files:
                file_content = file.read()
                month = month_label_from_filename(file.name)
                success, message = save_file_to_db(file.name, "income", month, file_content)
                if success:
                    st.success(f"✅ {file.name} uploaded")
                else:
                    st.info(f"ℹ️ {file.name} - {message}")
                file.seek(0)  # Reset file pointer
    
    with col2:
        st.write("**Expense Files (Compras/Gastos)**")
        expense_files = st.file_uploader(
            "Upload Expense Files",
            type=["xlsx"],
            accept_multiple_files=True,
            help="Upload monthly expense Excel files",
            key="expense_upload",
            label_visibility="collapsed"
        )
        
        if expense_files:
            for file in expense_files:
                file_content = file.read()
                month = month_label_from_filename(file.name)
                success, message = save_file_to_db(file.name, "expense", month, file_content)
                if success:
                    st.success(f"✅ {file.name} uploaded")
                else:
                    st.info(f"ℹ️ {file.name} - {message}")
                file.seek(0)
    
    st.divider()
    
    st.subheader("📁 Manage Uploaded Files")
    
    all_files = get_all_files()
    
    if all_files:
        files_df = pd.DataFrame(all_files, columns=["ID", "Filename", "Type", "Month", "Upload Date", "Data"])
        files_df = files_df.drop("Data", axis=1)
        files_df["Type"] = files_df["Type"].apply(lambda x: "📈 Income" if x == "income" else "📉 Expense")
        
        st.write(f"**Total files in database: {len(files_df)}**")
        
        # Display files by type
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Income Files**")
            income_df = files_df[files_df["Type"] == "📈 Income"].drop("Type", axis=1)
            if not income_df.empty:
                st.dataframe(income_df, hide_index=True, use_container_width=True)
            else:
                st.info("No income files uploaded yet")
        
        with col2:
            st.write("**Expense Files**")
            expense_df = files_df[files_df["Type"] == "📉 Expense"].drop("Type", axis=1)
            if not expense_df.empty:
                st.dataframe(expense_df, hide_index=True, use_container_width=True)
            else:
                st.info("No expense files uploaded yet")
        
        st.divider()
        
        st.subheader("🗑️ Delete Files")
        st.write("Select files to delete from the database:")
        
        files_to_delete = st.multiselect(
            "Select files to delete",
            options=files_df["ID"].tolist(),
            format_func=lambda x: f"{files_df[files_df['ID']==x]['Filename'].values[0]} ({files_df[files_df['ID']==x]['Month'].values[0]})",
            key="files_to_delete"
        )
        
        if files_to_delete:
            if st.button("🗑️ Delete Selected Files", type="primary"):
                for file_id in files_to_delete:
                    delete_file_from_db(file_id)
                st.success(f"Deleted {len(files_to_delete)} file(s)")
                st.rerun()
    else:
        st.info("No files uploaded yet. Upload files using the section above.")

# TAB: Financial Analysis
with main_tab2:
    # Load all files from database
    income_db_files = get_files_by_type("income")
    expense_db_files = get_files_by_type("expense")
    
    if income_db_files or expense_db_files:
        # Get all available months for filtering
        all_available_months = sorted(set(
            [month for _, _, month, _ in income_db_files] + 
            [month for _, _, month, _ in expense_db_files]
        ))
        
        if all_available_months:
            st.sidebar.header("📅 Date Range Filter")
            
            # Date range selector
            date_filter_option = st.sidebar.radio(
                "Filter by:",
                ["All Time", "Custom Range", "Last N Months"],
                index=0
            )
            
            filtered_months = all_available_months.copy()
            
            if date_filter_option == "Custom Range":
                col1, col2 = st.sidebar.columns(2)
                with col1:
                    start_month = st.selectbox(
                        "From:",
                        options=all_available_months,
                        index=0,
                        key="start_month"
                    )
                with col2:
                    end_month = st.selectbox(
                        "To:",
                        options=all_available_months,
                        index=len(all_available_months) - 1,
                        key="end_month"
                    )
                
                # Filter months in range
                filtered_months = [m for m in all_available_months if start_month <= m <= end_month]
                
            elif date_filter_option == "Last N Months":
                n_months = st.sidebar.slider(
                    "Number of months:",
                    min_value=1,
                    max_value=len(all_available_months),
                    value=min(6, len(all_available_months)),
                    key="n_months"
                )
                filtered_months = all_available_months[-n_months:]
            
            # Display current filter
            if date_filter_option != "All Time":
                st.sidebar.info(f"📊 Showing data for {len(filtered_months)} month(s): {filtered_months[0]} to {filtered_months[-1]}")
            else:
                st.sidebar.info(f"📊 Showing all available data ({len(filtered_months)} months)")
        else:
            filtered_months = []
        
        try:
            # Process income files from database (with filter)
            income_monthly_results = []
            income_all_rows = []
            
            if income_db_files:
                for file_id, filename, month, file_data in income_db_files:
                    # Apply month filter
                    if month not in filtered_months:
                        continue
                        
                    df = load_table(file_data)
                    amount_col = pick_amount_column(df)
                    res = analyze_income_df(df, amount_col)
                    income_monthly_results.append((month, res))
                    income_all_rows.append(res["df_clean"])
                
                if income_all_rows:
                    df_income_all = pd.concat(income_all_rows, ignore_index=True)
                    amount_col_income = pick_amount_column(df_income_all)
                    total_income_res = analyze_income_df(df_income_all, amount_col_income)
                else:
                    total_income_res = None
            else:
                total_income_res = None
            
            # Process expense files from database (with filter)
            expense_monthly_results = []
            expense_all_rows = []
            
            if expense_db_files:
                for file_id, filename, month, file_data in expense_db_files:
                    # Apply month filter
                    if month not in filtered_months:
                        continue
                        
                    df = load_table(file_data)
                    amount_col = pick_amount_column(df)
                    res = analyze_expense_df(df, amount_col)
                    expense_monthly_results.append((month, res))
                    expense_all_rows.append(res["df_clean"])
                
                if expense_all_rows:
                    df_expense_all = pd.concat(expense_all_rows, ignore_index=True)
                    amount_col_expense = pick_amount_column(df_expense_all)
                    total_expense_res = analyze_expense_df(df_expense_all, amount_col_expense)
                else:
                    total_expense_res = None
            else:
                total_expense_res = None
            
            # Check if we have any data after filtering
            if not income_monthly_results and not expense_monthly_results:
                st.warning("⚠️ No data available for the selected date range. Please adjust your filters.")
                st.stop()
            
            # Create analysis tabs
            tab1, tab2, tab3 = st.tabs(["💰 Overall KPIs", "📈 Income Analysis", "📉 Expense Analysis"])
            
            # TAB 1: OVERALL KPIs
            with tab1:
                st.header("Financial Overview")
                
                total_income = total_income_res["grand_total"] if total_income_res else 0
                total_expense = total_expense_res["grand_total"] if total_expense_res else 0
                profit = total_income - total_expense
                profit_margin = (profit / total_income * 100) if total_income > 0 else 0
                
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    st.metric("Total Income", f"€{total_income:,.2f}")
                with col2:
                    st.metric("Total Expenses", f"€{total_expense:,.2f}")
                with col3:
                    st.metric("Net Profit", f"€{profit:,.2f}", delta=f"{profit_margin:.1f}%")
                with col4:
                    num_months = max(len(income_monthly_results), len(expense_monthly_results))
                    if num_months > 0:
                        avg_profit = profit / num_months
                        st.metric("Avg Monthly Profit", f"€{avg_profit:,.2f}")
                
                # AI Insights Section
                if enable_ai and gemini_api_key:
                    st.divider()
                    st.subheader("🤖 AI-Powered Financial Insights")
                    
                    with st.spinner("Analyzing your financial data with AI..."):
                        ai_insights = generate_ai_insights(
                            income_monthly_results,
                            expense_monthly_results,
                            total_income,
                            total_expense,
                            profit,
                            gemini_api_key
                        )
                    
                    st.markdown(ai_insights)
                    
                    with st.expander("ℹ️ About AI Insights"):
                        st.write("""
                        These insights are generated by Google's Gemini AI based on your financial data.
                        The AI analyzes:
                        - Monthly trends in income and expenses
                        - Profit margins and financial ratios
                        - Category and channel performance
                        - Unusual patterns or concerning trends
                        
                        Use these insights as a starting point for deeper analysis.
                        """)
                
                st.divider()
                
                # Combined trend chart
                if income_monthly_results or expense_monthly_results:
                    st.subheader("Income vs Expenses Trend")
                    
                    all_months = sorted(set(
                        [m for m, _ in income_monthly_results] + 
                        [m for m, _ in expense_monthly_results]
                    ))
                    
                    trend_data = []
                    for month in all_months:
                        income_val = 0
                        expense_val = 0
                        
                        for m, res in income_monthly_results:
                            if m == month:
                                income_val = res["grand_total"]
                                break
                        
                        for m, res in expense_monthly_results:
                            if m == month:
                                expense_val = res["grand_total"]
                                break
                        
                        trend_data.append({
                            "Month": month,
                            "Income": income_val,
                            "Expenses": expense_val,
                            "Profit": income_val - expense_val
                        })
                    
                    trend_df = pd.DataFrame(trend_data)
                    
                    fig = go.Figure()
                    fig.add_trace(go.Scatter(
                        x=trend_df["Month"], y=trend_df["Expenses"],
                        mode='lines+markers', name='Expenses',
                        line=dict(color='red', width=3)
                    ))
                    fig.add_trace(go.Scatter(
                        x=trend_df["Month"], y=trend_df["Profit"],
                        mode='lines+markers', name='Profit',
                        line=dict(color='black', width=4)
                    ))
                    fig.add_trace(go.Scatter(
                        x=trend_df["Month"], y=trend_df["Income"],
                        mode='lines+markers', name='Income',
                        line=dict(color='green', width=3)
                    ))
                    fig.update_layout(
                        xaxis_title="Month",
                        yaxis_title="Amount (€)",
                        hovermode='x unified',
                        height=500
                    )
                    st.plotly_chart(fig, use_container_width=True)
                    
                    st.dataframe(
                        trend_df.style.format({
                            "Income": "€{:,.2f}",
                            "Expenses": "€{:,.2f}",
                            "Profit": "€{:,.2f}"
                        }),
                        hide_index=True,
                        use_container_width=True
                    )
                
                st.divider()
                
                col1, col2 = st.columns(2)
                
                if total_income_res:
                    with col1:
                        st.subheader("Income Breakdown")
                        fig_income_pie = px.pie(
                            total_income_res["tot_cat"],
                            values="Total",
                            names="Categoría",
                            title="By Category"
                        )
                        st.plotly_chart(fig_income_pie, use_container_width=True)
                
                if total_expense_res:
                    with col2:
                        st.subheader("Expense Breakdown")
                        fig_expense_pie = px.pie(
                            total_expense_res["tot_types"],
                            values="Total",
                            names="Tipo gasto",
                            title="By Type"
                        )
                        st.plotly_chart(fig_expense_pie, use_container_width=True)
            
            # TAB 2: INCOME ANALYSIS (same as before)
            with tab2:
                if total_income_res:
                    st.header("Income Analysis")
                    
                    subtab1, subtab2, subtab3 = st.tabs(["📊 Overview", "📋 Tables", "📉 Trends"])
                    
                    with subtab1:
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric("Total Revenue", f"€{total_income_res['grand_total']:,.2f}")
                        with col2:
                            st.metric("Number of Months", len(income_monthly_results))
                        with col3:
                            avg_monthly = total_income_res['grand_total'] / len(income_monthly_results) if income_monthly_results else 0
                            st.metric("Avg Monthly Revenue", f"€{avg_monthly:,.2f}")
                        
                        st.divider()
                        
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            st.subheader("Revenue by Category")
                            fig_cat = px.bar(
                                total_income_res["tot_cat"],
                                x="Categoría",
                                y="Total",
                                text="Total",
                                color="Total",
                                color_continuous_scale="Blues"
                            )
                            fig_cat.update_traces(texttemplate='€%{text:,.0f}', textposition='outside')
                            fig_cat.update_layout(showlegend=False, xaxis_tickangle=-45)
                            st.plotly_chart(fig_cat, use_container_width=True)
                            
                            st.dataframe(
                                total_income_res["tot_cat"].style.format({"Total": "€{:,.2f}", "Porcentaje": "{:.2f}%"}),
                                hide_index=True,
                                use_container_width=True
                            )
                        
                        with col2:
                            st.subheader("Revenue by Channel")
                            fig_channel = px.bar(
                                total_income_res["tot_channel"],
                                x="Canal",
                                y="Total",
                                text="Total",
                                color="Total",
                                color_continuous_scale="Greens"
                            )
                            fig_channel.update_traces(texttemplate='€%{text:,.0f}', textposition='outside')
                            fig_channel.update_layout(showlegend=False, xaxis_tickangle=-45)
                            st.plotly_chart(fig_channel, use_container_width=True)
                            
                            st.dataframe(
                                total_income_res["tot_channel"].style.format({"Total": "€{:,.2f}", "Porcentaje": "{:.2f}%"}),
                                hide_index=True,
                                use_container_width=True
                            )
                        
                        st.divider()
                        
                        st.subheader("Revenue Heatmap: Channel × Category")
                        pivot_for_heatmap = total_income_res["pivot_eur"].iloc[:-1, :-1]
                        fig_heatmap = px.imshow(
                            pivot_for_heatmap,
                            labels=dict(x="Category", y="Channel", color="Revenue (€)"),
                            x=pivot_for_heatmap.columns,
                            y=pivot_for_heatmap.index,
                            color_continuous_scale="RdYlGn",
                            aspect="auto"
                        )
                        fig_heatmap.update_traces(text=pivot_for_heatmap.values, texttemplate='€%{text:,.0f}')
                        st.plotly_chart(fig_heatmap, use_container_width=True)
                    
                    with subtab2:
                        month_options = ["TOTAL"] + [m for m, _ in income_monthly_results]
                        selected_month = st.selectbox("Select Month", month_options, key="income_month")
                        
                        if selected_month == "TOTAL":
                            selected_res = total_income_res
                        else:
                            selected_res = next(res for m, res in income_monthly_results if m == selected_month)
                        
                        st.subheader(f"Income Analysis for {selected_month}")
                        
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            st.write("**Revenue by Category (€)**")
                            st.dataframe(
                                selected_res["tot_cat"].style.format({"Total": "€{:,.2f}", "Porcentaje": "{:.2f}%"}),
                                hide_index=True,
                                use_container_width=True
                            )
                        
                        with col2:
                            st.write("**Revenue by Channel (€)**")
                            st.dataframe(
                                selected_res["tot_channel"].style.format({"Total": "€{:,.2f}", "Porcentaje": "{:.2f}%"}),
                                hide_index=True,
                                use_container_width=True
                            )
                        
                        st.write("**Cross-table: Channel × Category (€)**")
                        st.dataframe(
                            selected_res["pivot_eur"].style.format("€{:,.2f}"),
                            use_container_width=True
                        )
                        
                        st.write("**Cross-table: Channel × Category (%)**")
                        st.dataframe(
                            selected_res["pivot_pct"].style.format("{:.2f}%"),
                            use_container_width=True
                        )
                        
                        st.write("**'Pagos a cuenta' Counts**")
                        st.dataframe(
                            selected_res["pagos_counts"],
                            use_container_width=True
                        )
                    
                    with subtab3:
                        if len(income_monthly_results) > 1:
                            st.subheader("Monthly Income Trends")
                            
                            target_categories = ["Novias", "Premsades", "Formaciones"]
                            target_channels = ["TikTok", "Instagram", "Google"]
                            months_order = [month for month, _ in income_monthly_results]
                            
                            def _sum_for_label(df, label_col, label, amount_col_name):
                                if label not in df[label_col].unique():
                                    return 0.0
                                return pd.to_numeric(df.loc[df[label_col] == label, amount_col_name], errors="coerce").sum()
                            
                            cat_trend_df = pd.DataFrame(0.0, index=months_order, columns=target_categories)
                            chn_trend_df = pd.DataFrame(0.0, index=months_order, columns=target_channels)
                            
                            for month_name, res in income_monthly_results:
                                dfm = res["df_clean"]
                                amt_col_m = pick_amount_column(dfm)
                                for cat in target_categories:
                                    cat_trend_df.loc[month_name, cat] = _sum_for_label(dfm, "Categoría", cat, amt_col_m)
                                for ch in target_channels:
                                    chn_trend_df.loc[month_name, ch] = _sum_for_label(dfm, "Canal", ch, amt_col_m)
                            
                            cat_trend_df["TOTAL"] = cat_trend_df.sum(axis=1)
                            chn_trend_df["TOTAL"] = chn_trend_df.sum(axis=1)
                            
                            st.write("**Trends by Category**")
                            fig_cat_trend = go.Figure()
                            for col in cat_trend_df.columns:
                                line_width = 4 if col == "TOTAL" else 2
                                line_color = "black" if col == "TOTAL" else None
                                fig_cat_trend.add_trace(go.Scatter(
                                    x=cat_trend_df.index,
                                    y=cat_trend_df[col],
                                    mode='lines+markers',
                                    name=col,
                                    line=dict(width=line_width, color=line_color)
                                ))
                            fig_cat_trend.update_layout(
                                xaxis_title="Month",
                                yaxis_title="Revenue (€)",
                                hovermode='x unified'
                            )
                            st.plotly_chart(fig_cat_trend, use_container_width=True)
                            st.dataframe(cat_trend_df.style.format("€{:,.2f}"), use_container_width=True)
                            
                            st.write("**Trends by Channel**")
                            fig_chn_trend = go.Figure()
                            for col in chn_trend_df.columns:
                                line_width = 4 if col == "TOTAL" else 2
                                line_color = "black" if col == "TOTAL" else None
                                fig_chn_trend.add_trace(go.Scatter(
                                    x=chn_trend_df.index,
                                    y=chn_trend_df[col],
                                    mode='lines+markers',
                                    name=col,
                                    line=dict(width=line_width, color=line_color)
                                ))
                            fig_chn_trend.update_layout(
                                xaxis_title="Month",
                                yaxis_title="Revenue (€)",
                                hovermode='x unified'
                            )
                            st.plotly_chart(fig_chn_trend, use_container_width=True)
                            st.dataframe(chn_trend_df.style.format("€{:,.2f}"), use_container_width=True)
                        else:
                            st.info("Upload multiple monthly files to see trend analysis.")
                else:
                    st.info("👆 Please upload income files to see analysis.")
            
            # TAB 3: EXPENSE ANALYSIS  
            with tab3:
                if total_expense_res:
                    st.header("Expense Analysis")
                    
                    subtab1, subtab2, subtab3 = st.tabs(["📊 Overview", "📋 Tables", "📉 Trends"])
                    
                    with subtab1:
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric("Total Expenses", f"€{total_expense_res['grand_total']:,.2f}")
                        with col2:
                            st.metric("Number of Months", len(expense_monthly_results))
                        with col3:
                            avg_monthly = total_expense_res['grand_total'] / len(expense_monthly_results) if expense_monthly_results else 0
                            st.metric("Avg Monthly Expense", f"€{avg_monthly:,.2f}")
                        
                        st.divider()
                        
                        st.subheader("Expenses by Type")
                        fig_expense = px.bar(
                            total_expense_res["tot_types"],
                            x="Tipo gasto",
                            y="Total",
                            text="Total",
                            color="Total",
                            color_continuous_scale="Reds"
                        )
                        fig_expense.update_traces(texttemplate='€%{text:,.0f}', textposition='outside')
                        fig_expense.update_layout(showlegend=False, xaxis_tickangle=-45, height=600)
                        st.plotly_chart(fig_expense, use_container_width=True)
                        
                        st.dataframe(
                            total_expense_res["tot_types"].style.format({"Total": "€{:,.2f}", "Porcentaje": "{:.2f}%"}),
                            hide_index=True,
                            use_container_width=True
                        )
                        
                        st.divider()
                        
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            st.subheader("Variable Expenses")
                            fig_var = px.bar(
                                total_expense_res["tot_vars"],
                                x="Tipo gasto",
                                y="Total",
                                text="Total",
                                color="Total",
                                color_continuous_scale="Oranges"
                            )
                            fig_var.update_traces(texttemplate='€%{text:,.0f}', textposition='outside')
                            fig_var.update_layout(showlegend=False, xaxis_tickangle=-45)
                            st.plotly_chart(fig_var, use_container_width=True)
                            
                            st.dataframe(
                                total_expense_res["tot_vars"].style.format({"Total": "€{:,.2f}", "Porcentaje": "{:.2f}%"}),
                                hide_index=True,
                                use_container_width=True
                            )
                        
                        with col2:
                            st.subheader("Fixed/Operational Expenses")
                            fig_fixed = px.bar(
                                total_expense_res["tot_fixed"],
                                x="Tipo gasto",
                                y="Total",
                                text="Total",
                                color="Total",
                                color_continuous_scale="Purples"
                            )
                            fig_fixed.update_traces(texttemplate='€%{text:,.0f}', textposition='outside')
                            fig_fixed.update_layout(showlegend=False, xaxis_tickangle=-45)
                            st.plotly_chart(fig_fixed, use_container_width=True)
                            
                            st.dataframe(
                                total_expense_res["tot_fixed"].style.format({"Total": "€{:,.2f}", "Porcentaje": "{:.2f}%"}),
                                hide_index=True,
                                use_container_width=True
                            )
                    
                    with subtab2:
                        month_options = ["TOTAL"] + [m for m, _ in expense_monthly_results]
                        selected_month = st.selectbox("Select Month", month_options, key="expense_month")
                        
                        if selected_month == "TOTAL":
                            selected_res = total_expense_res
                        else:
                            selected_res = next(res for m, res in expense_monthly_results if m == selected_month)
                        
                        st.subheader(f"Expense Analysis for {selected_month}")
                        
                        st.write("**All Expenses by Type**")
                        st.dataframe(
                            selected_res["tot_types"].style.format({"Total": "€{:,.2f}", "Porcentaje": "{:.2f}%"}),
                            hide_index=True,
                            use_container_width=True
                        )
                        
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            st.write("**Variable Expenses**")
                            st.dataframe(
                                selected_res["tot_vars"].style.format({"Total": "€{:,.2f}", "Porcentaje": "{:.2f}%"}),
                                hide_index=True,
                                use_container_width=True
                            )
                        
                        with col2:
                            st.write("**Fixed/Operational Expenses**")
                            st.dataframe(
                                selected_res["tot_fixed"].style.format({"Total": "€{:,.2f}", "Porcentaje": "{:.2f}%"}),
                                hide_index=True,
                                use_container_width=True
                            )
                        
                        if not selected_res["unknown_accounts"].empty:
                            st.write("**⚠️ Unclassified Accounts (Review Needed)**")
                            st.dataframe(
                                selected_res["unknown_accounts"].style.format({"Total": "€{:,.2f}"}),
                                hide_index=True,
                                use_container_width=True
                            )
                    
                    with subtab3:
                        if len(expense_monthly_results) > 1:
                            st.subheader("Monthly Expense Trends")
                            
                            trend_variables = ["Flores", "Materiales (cristales etc)", "Packaging"]
                            trend_fixed = ["Otros", "Asesorías", "Publicidad y marketing"]
                            months_order = [month for month, _ in expense_monthly_results]
                            
                            def _sum_for_label_expense(df, label, amount_col_name):
                                if label not in df["Tipo gasto"].unique():
                                    return 0.0
                                return pd.to_numeric(df.loc[df["Tipo gasto"] == label, amount_col_name], errors="coerce").sum()
                            
                            var_trend_df = pd.DataFrame(0.0, index=months_order, columns=trend_variables)
                            fix_trend_df = pd.DataFrame(0.0, index=months_order, columns=trend_fixed)
                            
                            for month_name, res in expense_monthly_results:
                                dfm = res["df_clean"]
                                amt_col_m = pick_amount_column(dfm)
                                for label in trend_variables:
                                    var_trend_df.loc[month_name, label] = _sum_for_label_expense(dfm, label, amt_col_m)
                                for label in trend_fixed:
                                    fix_trend_df.loc[month_name, label] = _sum_for_label_expense(dfm, label, amt_col_m)
                            
                            var_trend_df["TOTAL"] = var_trend_df.sum(axis=1)
                            fix_trend_df["TOTAL"] = fix_trend_df.sum(axis=1)
                            
                            st.write("**Variable Expenses Trend**")
                            fig_var_trend = go.Figure()
                            for col in var_trend_df.columns:
                                line_width = 4 if col == "TOTAL" else 2
                                line_color = "black" if col == "TOTAL" else None
                                fig_var_trend.add_trace(go.Scatter(
                                    x=var_trend_df.index,
                                    y=var_trend_df[col],
                                    mode='lines+markers',
                                    name=col,
                                    line=dict(width=line_width, color=line_color)
                                ))
                            fig_var_trend.update_layout(
                                xaxis_title="Month",
                                yaxis_title="Expenses (€)",
                                hovermode='x unified'
                            )
                            st.plotly_chart(fig_var_trend, use_container_width=True)
                            st.dataframe(var_trend_df.style.format("€{:,.2f}"), use_container_width=True)
                            
                            st.write("**Fixed/Operational Expenses Trend**")
                            fig_fix_trend = go.Figure()
                            for col in fix_trend_df.columns:
                                line_width = 4 if col == "TOTAL" else 2
                                line_color = "black" if col == "TOTAL" else None
                                fig_fix_trend.add_trace(go.Scatter(
                                    x=fix_trend_df.index,
                                    y=fix_trend_df[col],
                                    mode='lines+markers',
                                    name=col,
                                    line=dict(width=line_width, color=line_color)
                                ))
                            fig_fix_trend.update_layout(
                                xaxis_title="Month",
                                yaxis_title="Expenses (€)",
                                hovermode='x unified'
                            )
                            st.plotly_chart(fig_fix_trend, use_container_width=True)
                            st.dataframe(fix_trend_df.style.format("€{:,.2f}"), use_container_width=True)
                        else:
                            st.info("Upload multiple monthly files to see trend analysis.")
                else:
                    st.info("👆 Please upload expense files to see analysis.")
        
        except Exception as e:
            st.error(f"Error processing files: {str(e)}")
            st.exception(e)
    else:
        st.info("👆 No files in database. Go to 'Upload & Manage Files' tab to upload files.")

# TAB 3: PERIOD COMPARISON
with main_tab3:
    st.header("⚖️ Period Comparison")
    
    # Load all files from database
    income_db_files = get_files_by_type("income")
    expense_db_files = get_files_by_type("expense")
    
    if income_db_files or expense_db_files:
        # Get all available months
        all_available_months = sorted(set(
            [month for _, _, month, _ in income_db_files] + 
            [month for _, _, month, _ in expense_db_files]
        ))
        
        if len(all_available_months) < 2:
            st.warning("⚠️ You need at least 2 months of data to perform comparisons. Please upload more files.")
            st.stop()
        
        # Extract years and quarters from months
        years = sorted(set([m[:4] for m in all_available_months]))
        
        # Comparison type selector
        st.subheader("Select Comparison Type")
        comparison_type = st.radio(
            "Compare by:",
            ["Month vs Month", "Quarter vs Quarter", "Year vs Year", "Month vs Rest of Year"],
            horizontal=True
        )
        
        st.divider()
        
        # Helper function to get months in a period
        def get_months_in_period(period_type, period_value):
            if period_type == "month":
                return [period_value]
            elif period_type == "quarter":
                year, quarter = period_value.split("-Q")
                q_num = int(quarter)
                start_month = (q_num - 1) * 3 + 1
                return [f"{year}-{m:02d}" for m in range(start_month, start_month + 3) 
                        if f"{year}-{m:02d}" in all_available_months]
            elif period_type == "year":
                return [m for m in all_available_months if m.startswith(period_value)]
            return []
        
        # Helper function to aggregate data for a period
        def get_period_data(months_list, data_type="income"):
            files = income_db_files if data_type == "income" else expense_db_files
            all_rows = []
            
            for file_id, filename, month, file_data in files:
                if month in months_list:
                    df = load_table(file_data)
                    amount_col = pick_amount_column(df)
                    if data_type == "income":
                        res = analyze_income_df(df, amount_col)
                    else:
                        res = analyze_expense_df(df, amount_col)
                    all_rows.append(res["df_clean"])
            
            if not all_rows:
                return None
            
            df_combined = pd.concat(all_rows, ignore_index=True)
            amount_col = pick_amount_column(df_combined)
            
            if data_type == "income":
                return analyze_income_df(df_combined, amount_col)
            else:
                return analyze_expense_df(df_combined, amount_col)
        
        # Period selection based on comparison type
        col1, col2 = st.columns(2)
        
        if comparison_type == "Month vs Month":
            with col1:
                st.markdown("### 📅 Period A")
                period_a = st.selectbox("Select Month A", all_available_months, key="period_a_month")
            with col2:
                st.markdown("### 📅 Period B")
                period_b = st.selectbox("Select Month B", all_available_months, 
                                       index=min(1, len(all_available_months)-1), key="period_b_month")
            
            months_a = [period_a]
            months_b = [period_b]
            period_a_label = period_a
            period_b_label = period_b
        
        elif comparison_type == "Quarter vs Quarter":
            # Build quarters list
            quarters = []
            for year in years:
                for q in range(1, 5):
                    quarter_months = [f"{year}-{m:02d}" for m in range((q-1)*3+1, q*3+1)]
                    if any(m in all_available_months for m in quarter_months):
                        quarters.append(f"{year}-Q{q}")
            
            if len(quarters) < 2:
                st.warning("⚠️ Not enough quarterly data available for comparison.")
                st.stop()
            
            with col1:
                st.markdown("### 📅 Period A")
                period_a = st.selectbox("Select Quarter A", quarters, key="period_a_quarter")
            with col2:
                st.markdown("### 📅 Period B")
                period_b = st.selectbox("Select Quarter B", quarters, 
                                       index=min(1, len(quarters)-1), key="period_b_quarter")
            
            months_a = get_months_in_period("quarter", period_a)
            months_b = get_months_in_period("quarter", period_b)
            period_a_label = period_a
            period_b_label = period_b
        
        elif comparison_type == "Year vs Year":
            if len(years) < 2:
                st.warning("⚠️ Not enough yearly data available for comparison.")
                st.stop()
            
            with col1:
                st.markdown("### 📅 Period A")
                period_a = st.selectbox("Select Year A", years, key="period_a_year")
            with col2:
                st.markdown("### 📅 Period B")
                period_b = st.selectbox("Select Year B", years, 
                                       index=min(1, len(years)-1), key="period_b_year")
            
            months_a = get_months_in_period("year", period_a)
            months_b = get_months_in_period("year", period_b)
            period_a_label = period_a
            period_b_label = period_b
        
        else:  # Month vs Rest of Year
            with col1:
                st.markdown("### 📅 Selected Month")
                selected_month = st.selectbox("Select Month", all_available_months, key="selected_month")
            with col2:
                st.markdown("### 📅 Rest of Year")
                year = selected_month[:4]
                st.info(f"Comparing against all other months in {year}")
            
            months_a = [selected_month]
            year_of_month = selected_month[:4]
            months_b = [m for m in all_available_months if m.startswith(year_of_month) and m != selected_month]
            
            if not months_b:
                st.warning(f"⚠️ No other months available in year {year_of_month} for comparison.")
                st.stop()
            
            period_a_label = selected_month
            period_b_label = f"Rest of {year_of_month}"
        
        st.divider()
        
        # Get data for both periods
        with st.spinner("Loading and analyzing data..."):
            income_a = get_period_data(months_a, "income")
            income_b = get_period_data(months_b, "income")
            expense_a = get_period_data(months_a, "expense")
            expense_b = get_period_data(months_b, "expense")
        
        # Display comparison
        st.subheader(f"Comparison: {period_a_label} → {period_b_label}")
        
        # Overall KPIs comparison
        st.markdown("### 💰 Overall Financial Metrics")
        
        total_income_a = income_a["grand_total"] if income_a else 0
        total_income_b = income_b["grand_total"] if income_b else 0
        total_expense_a = expense_a["grand_total"] if expense_a else 0
        total_expense_b = expense_b["grand_total"] if expense_b else 0
        profit_a = total_income_a - total_expense_a
        profit_b = total_income_b - total_expense_b
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            income_diff = total_income_b - total_income_a
            income_pct = ((total_income_b - total_income_a) / total_income_a * 100) if total_income_a > 0 else 0
            
            st.markdown("#### 📈 Income Change")
            st.markdown(f"<h1 style='text-align: center; color: {'green' if income_diff > 0 else 'red'};'>{income_pct:+.1f}%</h1>", unsafe_allow_html=True)
            st.markdown(f"<h3 style='text-align: center; color: {'green' if income_diff > 0 else 'red'};'>€{income_diff:+,.2f}</h3>", unsafe_allow_html=True)
            st.caption(f"Period A: €{total_income_a:,.2f}")
            st.caption(f"Period B: €{total_income_b:,.2f}")
        
        with col2:
            expense_diff = total_expense_b - total_expense_a
            expense_pct = ((total_expense_b - total_expense_a) / total_expense_a * 100) if total_expense_a > 0 else 0
            
            st.markdown("#### 💸 Expense Change")
            st.markdown(f"<h1 style='text-align: center; color: {'red' if expense_diff > 0 else 'green'};'>{expense_pct:+.1f}%</h1>", unsafe_allow_html=True)
            st.markdown(f"<h3 style='text-align: center; color: {'red' if expense_diff > 0 else 'green'};'>€{expense_diff:+,.2f}</h3>", unsafe_allow_html=True)
            st.caption(f"Period A: €{total_expense_a:,.2f}")
            st.caption(f"Period B: €{total_expense_b:,.2f}")
        
        with col3:
            profit_diff = profit_b - profit_a
            profit_pct = ((profit_b - profit_a) / abs(profit_a) * 100) if profit_a != 0 else 0
            
            st.markdown("#### 💰 Profit Change")
            st.markdown(f"<h1 style='text-align: center; color: {'green' if profit_diff > 0 else 'red'};'>{profit_pct:+.1f}%</h1>", unsafe_allow_html=True)
            st.markdown(f"<h3 style='text-align: center; color: {'green' if profit_diff > 0 else 'red'};'>€{profit_diff:+,.2f}</h3>", unsafe_allow_html=True)
            st.caption(f"Period A: €{profit_a:,.2f}")
            st.caption(f"Period B: €{profit_b:,.2f}")
        
        st.divider()
        
        # Income comparison
        if income_a and income_b:
            st.markdown("### 📈 Income Comparison")
            
            tab_cat, tab_chan = st.tabs(["By Category", "By Channel"])
            
            with tab_cat:
                # Merge category data (B - A for change)
                df_cat_a = income_a["tot_cat"].copy()
                df_cat_b = income_b["tot_cat"].copy()
                
                df_cat_a = df_cat_a.rename(columns={"Total": "Period A", "Porcentaje": "% A"})
                df_cat_b = df_cat_b.rename(columns={"Total": "Period B", "Porcentaje": "% B"})
                
                df_cat_compare = df_cat_a.merge(df_cat_b, on="Categoría", how="outer").fillna(0)
                df_cat_compare["Difference (€)"] = df_cat_compare["Period B"] - df_cat_compare["Period A"]
                df_cat_compare["Change (%)"] = ((df_cat_compare["Period B"] - df_cat_compare["Period A"]) / 
                                              df_cat_compare["Period A"].replace(0, 1) * 100).round(1)
                
                # Reorder columns to show change first
                df_cat_display = df_cat_compare[["Categoría", "Change (%)", "Difference (€)", "Period A", "% A", "Period B", "% B"]]
                
                # Chart
                fig_cat = go.Figure()
                fig_cat.add_trace(go.Bar(
                    name=period_a_label,
                    x=df_cat_compare["Categoría"],
                    y=df_cat_compare["Period A"],
                    marker_color='lightblue',
                    opacity=0.7
                ))
                fig_cat.add_trace(go.Bar(
                    name=period_b_label,
                    x=df_cat_compare["Categoría"],
                    y=df_cat_compare["Period B"],
                    marker_color='darkblue'
                ))
                fig_cat.update_layout(
                    barmode='group',
                    xaxis_tickangle=-45,
                    height=500,
                    yaxis_title="Revenue (€)"
                )
                st.plotly_chart(fig_cat, use_container_width=True)
                
                # Table with highlighted changes
                st.dataframe(
                    df_cat_display.style.format({
                        "Period A": "€{:,.2f}",
                        "Period B": "€{:,.2f}",
                        "Difference (€)": "€{:+,.2f}",
                        "% A": "{:.1f}%",
                        "% B": "{:.1f}%",
                        "Change (%)": "{:+.1f}%"
                    }),
                    hide_index=True,
                    use_container_width=True
                )
            
            with tab_chan:
                # Merge channel data (B - A for change)
                df_chan_a = income_a["tot_channel"].copy()
                df_chan_b = income_b["tot_channel"].copy()
                
                df_chan_a = df_chan_a.rename(columns={"Total": "Period A", "Porcentaje": "% A"})
                df_chan_b = df_chan_b.rename(columns={"Total": "Period B", "Porcentaje": "% B"})
                
                df_chan_compare = df_chan_a.merge(df_chan_b, on="Canal", how="outer").fillna(0)
                df_chan_compare["Difference (€)"] = df_chan_compare["Period B"] - df_chan_compare["Period A"]
                df_chan_compare["Change (%)"] = ((df_chan_compare["Period B"] - df_chan_compare["Period A"]) / 
                                               df_chan_compare["Period A"].replace(0, 1) * 100).round(1)
                
                # Reorder columns
                df_chan_display = df_chan_compare[["Canal", "Change (%)", "Difference (€)", "Period A", "% A", "Period B", "% B"]]
                
                # Chart
                fig_chan = go.Figure()
                fig_chan.add_trace(go.Bar(
                    name=period_a_label,
                    x=df_chan_compare["Canal"],
                    y=df_chan_compare["Period A"],
                    marker_color='lightgreen',
                    opacity=0.7
                ))
                fig_chan.add_trace(go.Bar(
                    name=period_b_label,
                    x=df_chan_compare["Canal"],
                    y=df_chan_compare["Period B"],
                    marker_color='darkgreen'
                ))
                fig_chan.update_layout(
                    barmode='group',
                    xaxis_tickangle=-45,
                    height=500,
                    yaxis_title="Revenue (€)"
                )
                st.plotly_chart(fig_chan, use_container_width=True)
                
                # Table
                st.dataframe(
                    df_chan_display.style.format({
                        "Period A": "€{:,.2f}",
                        "Period B": "€{:,.2f}",
                        "Difference (€)": "€{:+,.2f}",
                        "% A": "{:.1f}%",
                        "% B": "{:.1f}%",
                        "Change (%)": "{:+.1f}%"
                    }),
                    hide_index=True,
                    use_container_width=True
                )
        
        st.divider()
        
        # Expense comparison
        if expense_a and expense_b:
            st.markdown("### 📉 Expense Comparison")
            
            tab_all, tab_var, tab_fix = st.tabs(["All Expenses", "Variable Expenses", "Fixed Expenses"])
            
            with tab_all:
                # Merge expense data (B - A for change)
                df_exp_a = expense_a["tot_types"].copy()
                df_exp_b = expense_b["tot_types"].copy()
                
                df_exp_a = df_exp_a.rename(columns={"Total": "Period A", "Porcentaje": "% A"})
                df_exp_b = df_exp_b.rename(columns={"Total": "Period B", "Porcentaje": "% B"})
                
                df_exp_compare = df_exp_a.merge(df_exp_b, on="Tipo gasto", how="outer").fillna(0)
                df_exp_compare["Difference (€)"] = df_exp_compare["Period B"] - df_exp_compare["Period A"]
                df_exp_compare["Change (%)"] = ((df_exp_compare["Period B"] - df_exp_compare["Period A"]) / 
                                              df_exp_compare["Period A"].replace(0, 1) * 100).round(1)
                
                # Reorder columns
                df_exp_display = df_exp_compare[["Tipo gasto", "Change (%)", "Difference (€)", "Period A", "% A", "Period B", "% B"]]
                
                # Chart
                fig_exp = go.Figure()
                fig_exp.add_trace(go.Bar(
                    name=period_a_label,
                    x=df_exp_compare["Tipo gasto"],
                    y=df_exp_compare["Period A"],
                    marker_color='lightcoral',
                    opacity=0.7
                ))
                fig_exp.add_trace(go.Bar(
                    name=period_b_label,
                    x=df_exp_compare["Tipo gasto"],
                    y=df_exp_compare["Period B"],
                    marker_color='darkred'
                ))
                fig_exp.update_layout(
                    barmode='group',
                    xaxis_tickangle=-45,
                    height=600,
                    yaxis_title="Expenses (€)"
                )
                st.plotly_chart(fig_exp, use_container_width=True)
                
                # Table (negative change is good for expenses)
                st.dataframe(
                    df_exp_display.style.format({
                        "Period A": "€{:,.2f}",
                        "Period B": "€{:,.2f}",
                        "Difference (€)": "€{:+,.2f}",
                        "% A": "{:.1f}%",
                        "% B": "{:.1f}%",
                        "Change (%)": "{:+.1f}%"
                    }),
                    hide_index=True,
                    use_container_width=True
                )
            
            with tab_var:
                # Variable expenses comparison (B - A)
                df_var_a = expense_a["tot_vars"].copy()
                df_var_b = expense_b["tot_vars"].copy()
                
                df_var_a = df_var_a.rename(columns={"Total": "Period A", "Porcentaje": "% A"})
                df_var_b = df_var_b.rename(columns={"Total": "Period B", "Porcentaje": "% B"})
                
                df_var_compare = df_var_a.merge(df_var_b, on="Tipo gasto", how="outer").fillna(0)
                df_var_compare["Difference (€)"] = df_var_compare["Period B"] - df_var_compare["Period A"]
                df_var_compare["Change (%)"] = ((df_var_compare["Period B"] - df_var_compare["Period A"]) / 
                                              df_var_compare["Period A"].replace(0, 1) * 100).round(1)
                
                # Reorder columns
                df_var_display = df_var_compare[["Tipo gasto", "Change (%)", "Difference (€)", "Period A", "% A", "Period B", "% B"]]
                
                # Chart
                fig_var = go.Figure()
                fig_var.add_trace(go.Bar(
                    name=period_a_label,
                    x=df_var_compare["Tipo gasto"],
                    y=df_var_compare["Period A"],
                    marker_color='lightsalmon',
                    opacity=0.7
                ))
                fig_var.add_trace(go.Bar(
                    name=period_b_label,
                    x=df_var_compare["Tipo gasto"],
                    y=df_var_compare["Period B"],
                    marker_color='orange'
                ))
                fig_var.update_layout(
                    barmode='group',
                    xaxis_tickangle=-45,
                    height=500,
                    yaxis_title="Variable Expenses (€)"
                )
                st.plotly_chart(fig_var, use_container_width=True)
                
                st.dataframe(
                    df_var_display.style.format({
                        "Period A": "€{:,.2f}",
                        "Period B": "€{:,.2f}",
                        "Difference (€)": "€{:+,.2f}",
                        "% A": "{:.1f}%",
                        "% B": "{:.1f}%",
                        "Change (%)": "{:+.1f}%"
                    }),
                    hide_index=True,
                    use_container_width=True
                )
            
            with tab_fix:
                # Fixed expenses comparison (B - A)
                df_fix_a = expense_a["tot_fixed"].copy()
                df_fix_b = expense_b["tot_fixed"].copy()
                
                df_fix_a = df_fix_a.rename(columns={"Total": "Period A", "Porcentaje": "% A"})
                df_fix_b = df_fix_b.rename(columns={"Total": "Period B", "Porcentaje": "% B"})
                
                df_fix_compare = df_fix_a.merge(df_fix_b, on="Tipo gasto", how="outer").fillna(0)
                df_fix_compare["Difference (€)"] = df_fix_compare["Period B"] - df_fix_compare["Period A"]
                df_fix_compare["Change (%)"] = ((df_fix_compare["Period B"] - df_fix_compare["Period A"]) / 
                                              df_fix_compare["Period A"].replace(0, 1) * 100).round(1)
                
                # Reorder columns
                df_fix_display = df_fix_compare[["Tipo gasto", "Change (%)", "Difference (€)", "Period A", "% A", "Period B", "% B"]]
                
                # Chart
                fig_fix = go.Figure()
                fig_fix.add_trace(go.Bar(
                    name=period_a_label,
                    x=df_fix_compare["Tipo gasto"],
                    y=df_fix_compare["Period A"],
                    marker_color='plum',
                    opacity=0.7
                ))
                fig_fix.add_trace(go.Bar(
                    name=period_b_label,
                    x=df_fix_compare["Tipo gasto"],
                    y=df_fix_compare["Period B"],
                    marker_color='purple'
                ))
                fig_fix.update_layout(
                    barmode='group',
                    xaxis_tickangle=-45,
                    height=500,
                    yaxis_title="Fixed Expenses (€)"
                )
                st.plotly_chart(fig_fix, use_container_width=True)
                
                st.dataframe(
                    df_fix_display.style.format({
                        "Period A": "€{:,.2f}",
                        "Period B": "€{:,.2f}",
                        "Difference (€)": "€{:+,.2f}",
                        "% A": "{:.1f}%",
                        "% B": "{:.1f}%",
                        "Change (%)": "{:+.1f}%"
                    }),
                    hide_index=True,
                    use_container_width=True
                )
    
    else:
        st.info("👆 No files in database. Go to 'Upload & Manage Files' tab to upload files.")
                    