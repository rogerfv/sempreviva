HOW TO RUN THE APP

1. Double-click "dashboard.vbs"
2. The app will open automatically in your browser
3. Do not delete or move files inside this folder

If the app does not open:
- Make sure you extracted the ZIP fully
- Try double-clicking "dashboard.bat" once
