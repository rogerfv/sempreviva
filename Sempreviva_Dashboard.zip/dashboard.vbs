Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

' Set working directory to the folder where this .vbs lives
folder = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = folder

' Run the batch file hidden (0 = hidden window)
shell.Run Chr(34) & folder & "\dashboard.bat" & Chr(34), 0

Set shell = Nothing
Set fso = Nothing
