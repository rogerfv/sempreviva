@echo off
setlocal
cd /d "%~dp0"

REM Activate the local venv
call ".venv\Scripts\activate.bat"

REM Open browser (optional)
start "" "http://localhost:8501"

REM Run streamlit using python -m (more reliable than relying on PATH)
python -m streamlit run app.py --server.port 8501 --browser.gatherUsageStats false

endlocal
